import 'package:flutter/material.dart';
import 'package:untitled/drawe/drawe.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
            "Home Screen",
             style: TextStyle(color: Colors.brown),),

        centerTitle: true,
        flexibleSpace: const Image(
          image: AssetImage('assets/background.jpg'),
          fit: BoxFit.cover,
        ),
        backgroundColor: Colors.transparent,
      ),
      drawer: Drawe(),
      body: Center(
        child: Text("Any Questions??\n Good Nighht "),
      ),
    );
  }
}