import 'package:dio/dio.dart';
import 'package:untitled/todoList/todoList/model/todo_model.dart';

class TodoService {
  static Future<List> getTodos() async {
  Response response = await Dio()
      .get("https://jsonplaceholder.typicode.com/todos/");
  List data = response.data.map((i) => Todo.fromJson(i)).toList();

  return data;

  }
}