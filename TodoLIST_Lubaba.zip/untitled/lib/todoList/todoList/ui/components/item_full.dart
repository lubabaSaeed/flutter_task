import 'package:flutter/material.dart';
import 'package:untitled/todoList/todoList/model/todo_model.dart';


class ItemFull extends StatefulWidget {
  Todo todo;
  ItemFull({
    super.key,
    required this.todo,
  });

  @override
  State<ItemFull> createState() => _ItemFullState();
}

class _ItemFullState extends State<ItemFull> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.todo.id.toString()),
        centerTitle: true,
        backgroundColor: Colors.deepPurple[100],
        elevation: 5,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Text(
              widget.todo.userId.toString(),
              style: TextStyle(fontSize: 24),
            ),
            Text(
              widget.todo.title,
              style: TextStyle(fontSize: 24),
            ),
            Text(
              widget.todo.completed.toString(),
              style: TextStyle(fontSize: 24),
            ),
          ],
        ),
      ),
    );
  }
}
