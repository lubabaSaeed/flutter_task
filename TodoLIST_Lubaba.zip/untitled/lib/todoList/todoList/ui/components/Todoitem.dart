import 'package:flutter/material.dart';
import 'package:untitled/todoList/todoList/services/TodoService.dart';
import 'package:untitled/drawe/drawe.dart';
import 'package:untitled/todoList/todoList/model/todo_model.dart';
import 'package:transition/transition.dart';
import 'package:untitled/todoList/todoList/ui/components/item_full.dart';

class Todoitem extends StatefulWidget {
  Todo todo;
  Todoitem({super.key, required this.todo});

  @override
  State<Todoitem> createState() => _TodoitemState();
}

class _TodoitemState extends State<Todoitem> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(10),
      child: ListTile(
        title: Text(
          widget.todo.title,
          style: TextStyle(fontSize: 19,fontWeight: FontWeight.bold),
        ),
        subtitle: Text(
            ('id: ')+widget.todo.id.toString()+('   userId: ')+widget.todo.userId.toString(),
          style: TextStyle(fontSize: 18),
        ),
        trailing: Text(
          widget.todo.completed.toString(),
          style: TextStyle(fontSize: 16),
        ),
        onTap: () {
          Navigator.push(
              context,
              Transition(
                  child: ItemFull(
                    todo: widget.todo,
                  ),
                  transitionEffect: TransitionEffect.RIGHT_TO_LEFT));
        },
      ),
    );
  }
}