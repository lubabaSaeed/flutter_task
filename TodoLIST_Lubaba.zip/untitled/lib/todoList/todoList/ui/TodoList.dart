import 'package:flutter/material.dart';
import 'package:untitled/todoList/todoList/services/TodoService.dart';
import 'package:untitled/drawe/drawe.dart';
import 'package:untitled/todoList/todoList/model/todo_model.dart';
import 'package:untitled/todoList/todoList/ui/components/Todoitem.dart';

class TodoList extends StatefulWidget {
  const TodoList({super.key});

  @override
  State<TodoList> createState() => TodoListState();
}

class TodoListState extends State<TodoList> {
  List TodosList = [];

  void getAllCharacters() async {
    TodoService.getTodos().then((response) {
      setState(() {
        TodosList = response;
      });
      print(response);
    });
  }

  @override
  void initState() {
    super.initState();
    getAllCharacters();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Todo List API APP"),
        flexibleSpace: const Image(
        image: AssetImage('assets/background.jpg'),
        fit: BoxFit.cover,
      ),
      backgroundColor: Colors.transparent,
        elevation: 5,
      ),
      drawer: const Drawe(),
      body: ListView.builder(
        itemCount: TodosList.length,
        itemBuilder: (context, index) {
          return Todoitem(
            todo: TodosList[index],
          );
        },
      ),
    );
  }
}
