import 'package:flutter/material.dart';
import 'package:transition/transition.dart';
import 'package:untitled/api_app/breaking_bad_app/ui/breaking_bad.dart';
import 'package:untitled/todoList/todoList/ui/TodoList.dart';


class Drawe extends StatefulWidget {
  const Drawe({super.key});

  @override
  State<Drawe> createState() => _DraweState();
}

class _DraweState extends State<Drawe> {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child:
      ListView(

        children: [

          const UserAccountsDrawerHeader(
            currentAccountPicture: CircleAvatar(
              backgroundImage: AssetImage('assets/profile.jpg'),
            ),
            accountName: Text("Lubaba"),
            accountEmail: Text("lubaba@gmail.com"),
          ),

          ListTile(
            title: Text("Home Screen"),
            onTap: () {
              Navigator.of(context).pushNamed('/home');
            },
            splashColor: Colors.brown[100],
          ),
          ListTile(
            title: Text("LogOut"),
            onTap: () {
              Navigator.of(context).pushNamed('/login');
            },
            splashColor: Colors.brown[100],
          ),
          ListTile(
            title: const Text("Breaking Bad App"),
            onTap: () {
              Navigator.push(
              context,
              Transition(
              child: const BreakingBadApp(),
              transitionEffect: TransitionEffect.FADE));
            },
            splashColor: Colors.brown[100],

          ),
          ListTile(
            title: const Text("Todo List App"),
            onTap: () {
              Navigator.push(
                  context,
                  Transition(
                      child: TodoList(),
                      transitionEffect: TransitionEffect.FADE));
            },
            splashColor: Colors.brown[100],

          ),

        ],
      ),
    );
  }
}
